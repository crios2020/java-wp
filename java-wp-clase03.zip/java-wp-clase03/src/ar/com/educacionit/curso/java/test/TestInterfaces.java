package ar.com.educacionit.curso.java.test;

import java.util.Scanner;

import ar.com.educacionit.curso.java.interfaces.I_File;
import ar.com.educacionit.curso.java.utils.FileBinary;
import ar.com.educacionit.curso.java.utils.FileText;

public class TestInterfaces {
    public static void main(String[] args) throws Exception {
        I_File file=null;

        //file=new FileBinary();
        //file=new FileText();

        System.out.println("Ingrese 'FileBinary' o 'FileText'");
        String in=new Scanner(System.in).nextLine();

        //if(in.equalsIgnoreCase("FileBinary")) file=new FileBinary();
        //if(in.equalsIgnoreCase("FileText")) file=new FileText();

        file=(I_File)Class
                .forName("ar.com.educacionit.curso.java.utils."+in)
                .getConstructor()
                .newInstance();

        //app
        file.setText("hola");
        System.out.println(file.getText());
        file.info();

    }
}
