package ar.com.educacionit.curso.java.test;

import ar.com.educacionit.curso.java.entities.Cliente;
import ar.com.educacionit.curso.java.entities.Cuenta;
import ar.com.educacionit.curso.java.entities.Direccion;
import ar.com.educacionit.curso.java.entities.Persona;
import ar.com.educacionit.curso.java.entities.Vendedor;

public class TestHerencia {
    public static void main(String[] args) {
        System.out.println("-- dir1 --");
        Direccion dir1=new Direccion("Larrea",222,"2","b");
        System.out.println(dir1);

        System.out.println("-- dir2 --");
        Direccion dir2=new Direccion("Belgran",49,null,null,"Moron");
        System.out.println(dir2);

        System.out.println("-- cuenta1 --");
		Cuenta cuenta1=new Cuenta(1, "arg$");
		cuenta1.depositar(80000);
		cuenta1.depositar(140000);
		cuenta1.debitar(50000);
		System.out.println(cuenta1);

        System.out.println("-- vendedor1 --");
        Vendedor vendedor1=new Vendedor("Adela",33,dir1,1,230000);
        System.out.println(vendedor1);
        vendedor1.saludar();
        
        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente("Joaqin",44,vendedor1.getDireccion(),1,cuenta1);
        cliente1.getCuenta().depositar(40000);
        System.out.println(cliente1);
        cliente1.saludar();

        //Error Clase abstracta
        //Persona p1=new Persona("Rafael",33,dir2);

        System.out.println("**********************************************************************");

        //Poliformismo - Polimorfismo
        Persona p1=new Vendedor("David", 55, dir1, 10, 230000);
        Persona p2=new Cliente("Micaela", 28, dir2, 10, cuenta1);
        
        Object o1="Hola";
        o1=p1;


        p1.saludar();
        p2.saludar();

        //Casteo
        Vendedor v1=(Vendedor)p1;

        v1=(p1 instanceof Vendedor)?(Vendedor)p1:null;



    }
}
