package ar.com.educacionit.curso.java.test;

import java.util.ArrayList;

import ar.com.educacionit.curso.java.entities.ClienteEmpresa;
import ar.com.educacionit.curso.java.entities.ClientePersona;
import ar.com.educacionit.curso.java.entities.Cuenta;

public class TestRelaciones {
	public static void main(String[] args) {
		//Test Diagrama Relaciones

		//Testeo con Objetos Mocks - Objetos Simulados
		System.out.println("-- cuenta1 --");
		Cuenta cuenta1=new Cuenta(1, "arg$");
		cuenta1.depositar(80000);
		cuenta1.depositar(140000);
		cuenta1.debitar(50000);
		System.out.println(cuenta1);

		System.out.println("-- clienteP1 --");
		ClientePersona clienteP1=new ClientePersona(1, "Jose", 45, 2);
		
		Cuenta cuentaClienteP1=clienteP1.getCuenta();
		cuentaClienteP1.depositar(50000);
		clienteP1.getCuenta().depositar(50000);
		clienteP1.comprar();
		System.out.println(clienteP1);

		System.out.println("-- mariana --");
		ClientePersona mariana=new ClientePersona(2, "Mariana", 32, cuenta1);
		mariana.getCuenta().depositar(100000);
		System.out.println(mariana);
		System.out.println("-- gabriel --");
		ClientePersona gabriel=new ClientePersona(3, "Gabriel", 32, mariana.getCuenta());
		gabriel.getCuenta().debitar(80000);

		System.out.println(gabriel);
		System.out.println(mariana);

		System.out.println("-- clienteE1 --");
		ClienteEmpresa clienteE1=new ClienteEmpresa(1, "Fletes Luis", "Lima 111");

		ArrayList<Cuenta> cuentas = clienteE1.getCuentas();
		cuentas.add(new Cuenta(10,"arg$"));				// 0
		cuentas.add(new Cuenta(11,"Reales"));				// 1
		cuentas.add(new Cuenta(12, "U$S"));				// 2

		cuentas.get(0).depositar(250000);
		cuentas.get(0).depositar(500000);
		cuentas.get(0).debitar(120000);
		cuentas.get(1).depositar(60000);
		cuentas.get(2).depositar(150000);

		//cuentas.remove(2);

		System.out.println(clienteE1);

		//Recorrido forEach JDK5 o sup.
		//for (Cuenta cuenta : cuentas) {
		//	System.out.println(cuenta);
		//}

		cuentas.forEach(System.out::println);


		
	}
}
