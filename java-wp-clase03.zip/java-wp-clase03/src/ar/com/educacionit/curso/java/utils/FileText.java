package ar.com.educacionit.curso.java.utils;

import ar.com.educacionit.curso.java.interfaces.I_File;

public class FileText implements I_File{

    @Override
    public void setText(String text) {
        System.out.println("Escribiendo archivo de Texto!");
    }

    @Override
    public String getText() {
        return "Contenido de archivo de texto!";
    }
    
}
