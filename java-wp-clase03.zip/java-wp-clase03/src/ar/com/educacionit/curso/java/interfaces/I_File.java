package ar.com.educacionit.curso.java.interfaces;

public interface I_File {
    
    /*
     * - Una interface no tiene atributos de clase ni constructores.
     * - Solo puede tener atributos final o statics.
     * - Todos los miembros de una interface son publico.
     * - Sus métodos son abstractos y publicos
     * - Una clase puede implementar muchas interfaces
     */

    /**
     * La java DOC se hereda
     * Este método escribe en un archivo
     * @param text texto a escribir
     */
    void setText(String text);

    /**
     * Abre un archivo y lo lee
     * @return retorna el texto del archivo
     */
    String getText();

    //Métodos default JDK8 o sup
    default void info(){
        System.out.println("Interface I_File");
    }

}
