package ar.com.educacionit.curso.java.utils;

import ar.com.educacionit.curso.java.interfaces.I_File;

public class FileBinary implements I_File{

    @Override
    public void setText(String text) {
        System.out.println("Escribiendo archivo binario!");
    }

    @Override
    public String getText() {
        return "Contenido de archivo binario!";
    }
    
}
