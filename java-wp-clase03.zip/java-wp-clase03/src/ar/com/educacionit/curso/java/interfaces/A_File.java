package ar.com.educacionit.curso.java.interfaces;

import java.io.FileReader;

public abstract class A_File {

    private FileReader file;

    public A_File(FileReader file) {
        this.file = file;
    }

    /**
     * La java DOC se hereda
     * Este método escribe en un archivo
     * @param text texto a escribir
     */
    public abstract void setText(String text);

    /**
     * Abre un archivo y lo lee
     * @return retorna el texto del archivo
     */
    public abstract String getText();

    
}
