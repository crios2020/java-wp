package ar.com.educacionit.curso.java.test;

import ar.com.educacionit.curso.java.entities.Cuenta;

public class TestArrays {
    public static void main(String[] args) {
        
        //Vector o Arrays
        Cuenta[] cuentas=new Cuenta[5];
        cuentas[0]=new Cuenta(1,"arg$");
        cuentas[1]=new Cuenta(2,"Reales");
        cuentas[2]=new Cuenta(3,"U$S");
        cuentas[3]=new Cuenta(4,"Euros");
        cuentas[4]=new Cuenta(5,"uyu");

        //Recorrer el vector por indices
        //for(int a=0; a<cuentas.length;a++){
        //    System.out.println(cuentas[a]);
        //}

        //Recorrido forEach JDK5 o sup.
        for (Cuenta cuenta : cuentas) {
            System.out.println(cuenta);
        }



    }
}
