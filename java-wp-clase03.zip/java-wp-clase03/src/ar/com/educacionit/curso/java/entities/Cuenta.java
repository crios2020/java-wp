package ar.com.educacionit.curso.java.entities;

public class Cuenta {
	
	private int nro;
	private String moneda;
	private double saldo;
	
	public Cuenta(int nro, String moneda) {
		super();
		this.nro = nro;
		this.moneda = moneda;
	}

	@Override
	public String toString() {
		return "Cuenta [nro=" + nro + ", moneda=" + moneda + ", saldo=" + saldo + "]";
	}

	public int getNro() {
		return nro;
	}

	public void setNro(int nro) {
		this.nro = nro;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

}
