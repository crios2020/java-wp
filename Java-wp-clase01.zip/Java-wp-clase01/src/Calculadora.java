
public class Calculadora {
	public double sumar(double nro1, double nro2) {
		//TODO hacer método sumar
		return 0;
	}
	
	public double restar(double nro1, double nro2) {
		//TODO hacer método restar
		return 0;
	}
	
	public double multiplicar(double nro1, double nro2) {
		//TODO hacer método multiplicar
		return 0;
	}
	
	public double dividir(double nro1, double nro2) {
		//TODO hacer método dividir, en caso de que nro2 sea distinto de 0
		return 0;
	}
}
