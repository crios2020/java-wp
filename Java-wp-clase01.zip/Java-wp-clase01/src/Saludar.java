public class Saludar{
	
	public static final String ANSI_BLACK = "\u001B[30m";
	public static final String ANSI_RED = "\u001B[31m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_YELLOW = "\u001B[33m";
	public static final String ANSI_BLUE = "\u001B[34m";
	public static final String ANSI_PURPLE = "\u001B[35m";
	public static final String ANSI_CYAN = "\u001B[36m";
	public static final String ANSI_WHITE = "\u001B[37m";
	public static final String ANSI_RESET = "\u001B[0m";
	
	public static void main(String[] args){
		if(args.length==2){
			if(args[1].equalsIgnoreCase("negro")) System.out.println(ANSI_BLACK+"Hola "+args[0]+ANSI_RESET);
			if(args[1].equalsIgnoreCase("rojo")) System.out.println(ANSI_RED+"Hola "+args[0]+ANSI_RESET);
			if(args[1].equalsIgnoreCase("verde")) System.out.println(ANSI_GREEN+"Hola "+args[0]+ANSI_RESET);
			if(args[1].equalsIgnoreCase("amarillo")) System.out.println(ANSI_YELLOW+"Hola "+args[0]+ANSI_RESET);
			if(args[1].equalsIgnoreCase("azul")) System.out.println(ANSI_BLUE+"Hola "+args[0]+ANSI_RESET);
		}else{
			System.out.println(ANSI_RED+"Ingrese su nombre y un color (negro,rojo,verde,amarillo,azul)"+ANSI_RESET);
		}
	}
}
