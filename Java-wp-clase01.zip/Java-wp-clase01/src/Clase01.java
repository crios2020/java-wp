import javax.swing.JOptionPane;

/**
 * Clase principal del proyecto.
 * 
 * @author carlos
 *
 */
public class Clase01 {
	/**
	 * Punto de entrada del proyecto!
	 * 
	 * @param args parámetros que ingresan de consola.
	 */
	public static void main(String[] args) {

		/*
		 * Curso: Java SE Web Programming 40 hs Días: Sábados 10:00 a 14:00 hs Profe:
		 * Carlos Ríos carlos.rios@educacionit.com
		 * 
		 * Materiales: alumni.educacionit.com user: email pass: dni
		 * 
		 * Github: https://github.com/crios2020/java-wp
		 * 
		 * Software: JDK 11 LTS o JDK 17 LTS
		 * 
		 * LTS Long Term Support 8 años
		 * 
		 * JDK Java Development Kit (Kit de Desarrollo Java)
		 * 
		 * https://www.oracle.com/java/technologies/downloads/
		 * 
		 * 
		 * IDE (Integrated Development Enviroment) Entorno de Desarrollo Integrado
		 * Eclipse - Netbeans - STS Spring Tools Suite - Visual Studio Code - IntelliJ
		 * 
		 */

		System.out.println("Versión de Java: " + System.getProperty("java.version")); // versión de Java
		System.out.println("Hola Mundo");

		// Comentarios de una sola linea
		/* Bloque de comentarios */

		/**
		 * Comentario Java DOC Este comentario se coloca delante de una declaración de
		 * clase o método. Puede Visualizarce desde fuera del binario.
		 */

		// TODO tarea pendiente

		// Tipo de datos primitivos

		// Lenguajes de tipado fuerte: JAVA C#.net C C++ Visual Basic TypeScript
		// Lenguajes de tipado debil: PHP Python JavaScript

		// Tipo de datos Enteros
		// Declaración de variable
		int x; // Declaración de variable
		x = 38; // Asignación de valor
		int x2 = 26; // Declaración y asignación de valor
		int x3 = 16, x4 = 65, x5 = 32; // declaración y asignación multiple

		// Una variable se puede declrarar una sola vez, pero puede tener multiples
		// asignaciones
		// int x;
		x = 23;
		x = 26;
		x = 29;

		// x="67"; //Error no respeto el tipo de datos.

		// Tipo boolean 1 byte
		boolean bo = true; // 1
		System.out.println(bo);
		bo = false; // 0
		System.out.println(bo);
		/*
		 * boolean bo=true;
		 * 
		 * 1 --------
		 */

		// Tipo byte 1 byte
		byte by = -100;
		System.out.println(by);
		by = 100;
		System.out.println(by);

		/*
		 * byte by=-100;
		 * 
		 * |----|----| -128 0 127
		 * 
		 * 
		 * byteU No disponible en Java
		 * 
		 * |---------| 0 255
		 */

		// Tipo short 2 bytes
		short sh = 3000;
		System.out.println(sh);

		// Tipo int 4 bytes
		int in = 2000000000;
		System.out.println(in);

		// Tipo long 8 bytes
		long lo = 3000000000L;
		System.out.println(lo);

		// Tipo char (unicode) 2 bytes unsigned
		char ch = 65;
		System.out.println(ch);
		ch += 32;
		System.out.println(ch);

		ch = 'C'; // literal de char
		System.out.println(ch);

		// Tipo de datos de punto flotante

		// Tipo float 32 bits
		float fl = 5.25f;
		System.out.println(fl);

		// Tipo double 64 bits
		double dl = 5.25;
		System.out.println(dl);

		fl = 10;
		dl = 10;
		System.out.println(fl / 3);
		System.out.println(dl / 3);

		fl = 100;
		dl = 100;
		System.out.println(fl / 3);
		System.out.println(dl / 3);

		// Clase BigDecimal

		// Clase String
		String st = "hola";
		System.out.println(st);

		/*
		 * Java 9 o inf private final char[] value; String st="hola"; 8 bytes
		 * 
		 * Java 10 o sup private final byte[] value; String st="hola"; 4 bytes
		 * 
		 */

		// Estructuras de programación
		String texto = "Esto es una cadena de texto!";
		System.out.println(texto);
		// System.out.println(texto.value[0]);
		System.out.println(texto.charAt(0));

		// Recorrido del vector texto
		for (int a = 0; a < texto.length(); a++) {
			System.out.print(texto.charAt(a));
		}
		System.out.println();

		// Imprimir texto en mayusculas
		for (int a = 0; a < texto.length(); a++) {
			char car = texto.charAt(a);
			if (car >= 97 && car <= 122) car -= 32;
			System.out.print(car);
		}
		System.out.println();
		
		// Operador ternario ?
		for (int a = 0; a < texto.length(); a++) {
			char car = texto.charAt(a);
			System.out.print((car >= 97 && car <= 122)?car-=32:car);
		}
		System.out.println();

		// Imprimir texto en minusculas
		for (int a = 0; a < texto.length(); a++) {
			char car = texto.charAt(a);
			System.out.print((car >= 65 && car <= 90)?car+=32:car);
		}
		System.out.println();
		
		System.out.println(texto.toLowerCase());
		System.out.println(texto.toUpperCase());
		
		JOptionPane.showMessageDialog(null, "Hola a todos!!!");
		
	}
}
