public class Parte2{
	/**
	 * String[] args argumentos que ingresan por consola
	 */
	public static void main(String[] args){
		System.out.println("Longitud vector args: "+args.length);
		for(int a=0; a< args.length; a++){
			System.out.println(args[a]);
		}
	}
}
