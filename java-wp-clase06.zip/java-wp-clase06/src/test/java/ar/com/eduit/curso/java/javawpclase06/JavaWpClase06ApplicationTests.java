package ar.com.eduit.curso.java.javawpclase06;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaWpClase06ApplicationTests {

	@Test
	void contextLoads() {
	}

}
