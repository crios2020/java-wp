package ar.com.eduit.curso.java.colegio.test;

import ar.com.eduit.curso.java.colegio.entities.Curso;
import ar.com.eduit.curso.java.colegio.enums.Dia;
import ar.com.eduit.curso.java.colegio.enums.Turno;
import ar.com.eduit.curso.java.colegio.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.colegio.repositories.list.CursoRepository;

public class TestRepository {
    public static void main(String[] args) {
        I_CursoRepository cr=new CursoRepository();

        cr.save(new Curso("Java","Rios",Dia.VIERNES,Turno.MAÑANA));
        cr.save(new Curso("JavaScript","Sanchez",Dia.VIERNES,Turno.MAÑANA));
        cr.save(new Curso("html","Torres",Dia.VIERNES,Turno.MAÑANA));
        cr.save(new Curso("Jardineria","Gomez",Dia.VIERNES,Turno.MAÑANA));
        cr.save(new Curso("Java","Rios",Dia.JUEVES,Turno.NOCHE));

        cr.getAll().forEach(System.out::println);
        System.out.println("**************************************************************");
        cr.getLikeTitulo("jar").forEach(System.out::println);
        System.out.println("**************************************************************");
        cr.getLikeProfesor("ri").forEach(System.out::println);

    }
}
