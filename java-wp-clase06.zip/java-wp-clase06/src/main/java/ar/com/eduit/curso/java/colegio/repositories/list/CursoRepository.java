package ar.com.eduit.curso.java.colegio.repositories.list;

import java.util.ArrayList;
import java.util.List;

import ar.com.eduit.curso.java.colegio.entities.Curso;
import ar.com.eduit.curso.java.colegio.repositories.interfaces.I_CursoRepository;

public class CursoRepository implements I_CursoRepository{
    
    private List<Curso>list;

    

    public CursoRepository() {
        list=new ArrayList();
    }

    @Override
    public void save(Curso curso) {
        list.add(curso);
    }

    @Override
    public void remove(Curso curso) {
        list.remove(curso);
    }

    @Override
    public void update(Curso curso) {
        
    }

    @Override
    public List<Curso> getAll() {
        return list;
    }
    
}
