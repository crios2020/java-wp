package ar.com.eduit.curso.java.colegio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaWpClase06Application {

	public static void main(String[] args) {
		SpringApplication.run(JavaWpClase06Application.class, args);
	}

}
