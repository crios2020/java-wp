package ar.com.eduit.curso.java.colegio.test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.time.LocalTime;

import ar.com.eduit.curso.java.colegio.connectors.Connector;

public class TestConnector {
    public static void main(String[] args) {
        System.out.println(LocalTime.now());
        try(Connection conn=Connector.getConnection()){
            ResultSet rs=conn.createStatement().executeQuery("select version()");
            if(rs.next()) System.out.println(rs.getString(1));
        }catch(Exception e){
            System.out.println(e);
        }
        System.out.println(LocalTime.now());
    }
}
