package ar.com.eduit.curso.java.colegio.repositories.jdbc;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

import ar.com.eduit.curso.java.colegio.entities.Curso;
import ar.com.eduit.curso.java.colegio.repositories.interfaces.I_CursoRepository;

public class CursoRepository implements I_CursoRepository{

    private Connection conn;

    public CursoRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Curso> getAll() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void remove(Curso curso) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void save(Curso curso) {
        //No hacer esto!!!
        //SQLInjection
        //try (Statement st=conn.createStatement()) {
        //    st.executeQuery(
        //        "insert into cursos (titulo,profesor,dia,turnos) values"+ 
        //        "('"+curso.getTitulo()+"','"+curso.getProfesor()+
        //        "','"+curso.getDia()+"','"+curso.getTurno()+"')"
        //    );
        //} catch (Exception e) {
        //    System.out.println(e);
        //}

        //usar PreparesStatement
    }

    @Override
    public void update(Curso curso) {
        // TODO Auto-generated method stub
        
    }
    
}
