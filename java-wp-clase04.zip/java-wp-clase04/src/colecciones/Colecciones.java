package colecciones;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

public class Colecciones {

	public static void main(String[] args) {
		
		//Arrays - Vectores
		Auto[] autos=new Auto[4];
		autos[0]=new Auto("Ford","Fiesta","Rojo");
		autos[1]=new Auto("Fiat","Uno","Gris");
		autos[2]=new Auto("VW","Gol","Blanco");
		autos[3]=new Auto("Renault","Logan","Negro");
		
		//Recorrido por indices
		//for(int a=0; a<autos.length; a++) {
		//	System.out.println(autos[a]);
		//}

		//Recorrido forEach
		for (Auto auto : autos) {
			System.out.println(auto);
		}
		
		//Framework Collections
		
		//Interface List - Representa una lista tipo vector dinamica con indices
		List lista1;			//Lista de tipo Object
		lista1=new ArrayList(10);	
		//lista1=new LinkedList();
		//lista1=new Vector();
		
		lista1.add(new Auto("Citroen","C4","Bordo"));			// 0
		lista1.add(new Auto("Peugeot","308","Negro"));			// 1
		lista1.add("Hola");										// 2
		lista1.add("Chau");										// 3	
		lista1.add(20);											// 4
		
		//lista1.remove(3);
		
		//copiar los autos del vector autos a lista1
		for(Auto a: autos) lista1.add(a);
		
		System.out.println("*************************************************************************");
		//Recorrido por indices
		for(int a=0; a<lista1.size(); a++) {
			System.out.println(lista1.get(a));
		}
		
		System.out.println("*************************************************************************");
		//Recorrido forEach
		for(Object o:lista1) {
			System.out.println(o);
		}
		
		//TODO método forEach JDK 8
		
	}

}
