package excepciones;

public class Logica {
	public static void main(String[] args) {
		// Operadores Lógicos

		// Operador Nombre
		// && (Shift 6) AND
		// || (altGR 1) OR
		// == EQUALS
		// != NOT EQUALS
		// ! NOT
		// < <= > >= Comparación

		// Tabla de Verdad

		// 	X 	Y 	OR 	AND
		// 	F 	F 	F 	F
		// 	F 	V 	V 	F
		// 	V 	F 	V 	F
		// 	V 	V 	V 	V
		
		boolean tp=true;
		boolean examen=false;
		

		//Para aprobar la materia es necesario aprobar un TP o Rendir Examen
		System.out.println(tp || examen);			//Operador OR logico
		System.out.println(tp | examen);			//Operador OR binario
		
		//Para aprobar la materia es necesario aprobar un TP y Rendir Examen
		System.out.println(tp && examen);			//Operador AND logico
		System.out.println(tp & examen);			//Operador AND binario
		
		// Para que te otorguen el credito, necesito tener garantia hipotecaria y sueldo
		// mayor a 300000
		// y acreditar antiguedad laboral >5 años o sino hay antiguedad ser
		// monotributista categoria f.

		boolean garantia = false;
		int sueldo = 320000;
		int antiguedadLaboral = 7;
		boolean monotributistaF = false;

		System.out.println(garantia && sueldo > 300000 && (antiguedadLaboral > 5 || monotributistaF));


		
	}
}
