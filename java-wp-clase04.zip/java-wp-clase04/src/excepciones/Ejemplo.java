package excepciones;

public class Ejemplo {

	public static void main(String[] args) {
		
		System.out.println("Hoy es Sábado!!!      1");
		System.out.println("Hoy es Sábado!!!      2");
		System.out.println("Hoy es Sábado!!!      3");
		System.out.println("Hoy es Sábado!!!      4");
		System.out.println("Hoy es Sábado!!!      5");
		System.out.println("Hoy es Sábado!!!      6");
		System.out.println("Hoy es Sábado!!!      7");
		System.out.println("Hoy es Sábado!!!      8");
		System.out.println("Hoy es Sábado!!!      9");
		System.out.println("Hoy es Sábado!!!      10");
		System.out.println("Hoy es Sábado!!!      11");
		System.out.println("Hoy es Sábado!!!      12");
		System.out.println("Hoy es Sábado!!!      13");
		System.out.println("Hoy es Sábado!!!      14");
		System.out.println("Hoy es Sábado!!!      15");
		System.out.println("Hoy es Sábado!!!      16");
		System.out.println("Hoy es Sábado!!!      17");
		System.out.println("Hoy es Sábado!!!      18");
		System.out.println("Hoy es Sábado!!!      19");
		System.out.println("Hoy es Sábado!!!      20");
		System.err.println("Ocurrio un error!!!");
		

	}

}
