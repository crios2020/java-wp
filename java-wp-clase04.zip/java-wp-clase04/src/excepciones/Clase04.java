package excepciones;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Clase04 {

	public static void main(String[] args) {
		// Clase 04 Manejo de Exceptions

		// System.out.println(10/0); //Lanza Exception
		// System.out.println("Esta sentencia no se ejecuta!");

		/*
		 * Estructura try - catch - finally
		 * 
		 * try { //Obligatorio - Colocar aquì las sentencias que pueden lanzar una
		 * exception. - Las sentencias dentro del bloque try, tienen màs costo de
		 * hardware. - Si las sentencias del bloque try se ejecutan normalmente, el
		 * bloque termina y continua el control de ejecución en el bloque finally. - Si
		 * ocurre un error, se lanza una exception y el control de ejecuciòn va al
		 * bloque catch, el programa no se detiene! } catch (Exception e){ //Obligatorio
		 * - Este bloque se ejecuta en caso de Exception. - Se recibe como parámetro un
		 * objeto del tipo Exception. - El bloque termina normalmente y continual el
		 * contro de ejecucciòn en el bloque finally } finally { //Opcional - Este
		 * bloque se ejecuta siempre. - Las variable declaradas en try y catch estan
		 * fuera de scope. }
		 * 
		 * - El programa termina normalmente!
		 */

		/*
		 * try { System.out.println(30/0); //lanza exception
		 * System.out.println("Esta linea no se ejecuta!"); } catch (Exception e) {
		 * System.out.println("Ocurrio un error!"); System.out.println(e);
		 * e.printStackTrace(); } finally {
		 * System.out.println("Este bloque se ejecuta siempre!"); }
		 * System.out.println("El programa termina normalmente!");
		 */

		try {
			// GeneradorExceptions.generar();
			// GeneradorExceptions.generar(true);
			// GeneradorExceptions.generar("38x");
			// GeneradorExceptions.generar(null, 2);
			// GeneradorExceptions.generar("Hola", 20);

		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println(e); // Consola sincronizada
			// System.err.println(e); //Consola no sincronizada
		}
		// System.out.println("El programa termina normalmente!");

		// Checked UnChecked Exception
		// GeneradorExceptions.generar("38x"); //unchecked exception
		// FileReader in=new FileReader("texto.txt"); //checked exception

		/*
		 * try { in=new FileReader("texto.txt"); } catch (FileNotFoundException e) {
		 * e.printStackTrace(); }
		 */

		// Captura personalizada de Exceptions (Multicatch)

		try {
			// GeneradorExceptions.generar();
			// GeneradorExceptions.generar(true);
			// GeneradorExceptions.generar("38x");
			// GeneradorExceptions.generar(null, 2);
			// GeneradorExceptions.generar("hola",20);
			FileReader in = new FileReader("texto.txt");
		} catch (ArithmeticException e) {
			System.out.println("División / 0");
			// } catch (ArrayIndexOutOfBoundsException e) { System.out.println("Indice fuera
			// de rango!");
		} catch (NumberFormatException e) {
			System.out.println("Formato de número incorrecto!");
		} catch (NullPointerException e) {
			System.out.println("Puntero Nulo!");
			// } catch (StringIndexOutOfBoundsException e) { System.out.println("Indice
			// fuera de rango!");
			// } catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e)
			// { System.out.println("Indice fuera de rango!"); //Multicatch JDK 5 o sup
		} catch (IndexOutOfBoundsException e) {
			System.out.println("Indice fuera de rango!");
		} catch (FileNotFoundException e) {
			System.out.println("Archivo no encontrado!");
		} catch (IOException e) {
			System.out.println("Error I/O");
		} catch (Exception e) {
			System.out.println("Ocurrio un error no esperado!");
		}

		// Uso de Exceptions parar validar reglas de negocio
		Vuelo v1 = new Vuelo("AER1234", 100);
		Vuelo v2 = new Vuelo("FLB1111", 100);

		try {
			v1.venderPasajes(50);
			v2.venderPasajes(20);
			v1.venderPasajes(30);
			v2.venderPasajes(20);
			v1.venderPasajes(30); // Esta venta lanza una exception
			v2.venderPasajes(10); // Esta venta no se hace
		} catch (NoHayMasPasajesException e) {
			System.out.println(e);
		}

		System.out.println(v1);
		System.out.println(v2);

		// No hacer esto, es código obsoleto

		/*
		FileReader in;
		try {
			in = new FileReader("texto.txt");
			try {
				System.out.println(in.read());
				in.close();
			} catch (FileNotFoundException e) {
				System.out.println("Archivo no encontrado!");
			} catch (IOException e) {
				System.out.println("Problemas al leer el archivo!");
				in.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		*/

		// Closeable - AutoCloseable JDK 7 o sup
		// Try with resources	JDK 7 o sup
		try (FileReader in=new FileReader("texto.txt")) {
			System.out.println(in.read());
			//in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
