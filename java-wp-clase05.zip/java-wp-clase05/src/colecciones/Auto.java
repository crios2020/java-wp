package colecciones;

import java.util.Objects;

public class Auto implements Comparable<Auto> {
	
	private String marca;
	private String modelo;
	private String color;
	
	public Auto(String marca, String modelo, String color) {
		super();
		this.marca = marca;
		this.modelo = modelo;
		this.color = color;
	}

	@Override
	public int compareTo(Auto para) {
		String thisAuto=this.marca+","+this.modelo+","+this.color;
		String paraAuto=para.marca+","+para.modelo+","+para.color;
		return thisAuto.compareTo(paraAuto)*-1;
	}

	@Override
	public String toString() {
		return "Auto [marca=" + marca + ", modelo=" + modelo + ", color=" + color + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(color, marca, modelo);
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)return false;
		return this.hashCode()==obj.hashCode();

	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

}
