package colecciones;

import java.time.LocalTime;
//import java.util.*;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;
import java.util.Vector;

public class Colecciones {

	public static void main(String[] args) {
		
		//Arrays - Vectores
		Auto[] autos=new Auto[4];
		autos[0]=new Auto("Ford","Fiesta","Rojo");
		autos[1]=new Auto("Fiat","Uno","Gris");
		autos[2]=new Auto("VW","Gol","Blanco");
		autos[3]=new Auto("Renault","Logan","Negro");
		
		//Recorrido por indices
		//for(int a=0; a<autos.length; a++) {
		//	System.out.println(autos[a]);
		//}

		//Recorrido forEach			JDK 5 o sup
		for (Auto auto : autos) {
			System.out.println(auto);
		}
		
		//Framework Collections
		
		//Interface List - Representa una lista tipo vector dinamica con indices
		List lista1;			//Lista de tipo Object
		lista1=new ArrayList();	
		//lista1=new LinkedList();
		//lista1=new Vector();
		
		lista1.add(new Auto("Citroen","C4","Bordo"));			// 0
		lista1.add(new Auto("Peugeot","308","Negro"));			// 1
		lista1.add("Hola");										// 2
		lista1.add("Chau");										// 3	
		lista1.add(20);											// 4
		
		//lista1.remove(3);
		
		//copiar los autos del vector autos a lista1
		for(Auto a: autos) lista1.add(a);
		
		System.out.println("*************************************************************************");
		//Recorrido por indices
		//for(int a=0; a<lista1.size(); a++) {
		//	System.out.println(lista1.get(a));
		//}
		
		System.out.println("*************************************************************************");
		//Recorrido forEach
		//for(Object o:lista1) {
		//	System.out.println(o);
		//}
		
		//método forEach JDK 8
		//Lambda Expression
		
		//lista1.forEach(o->System.out.println(o));
		
		//lista1.forEach(o->{
		//	System.out.println(o);
		//	System.out.println("-");
		//});
		
		lista1.forEach(System.out::println);
		
		
//		LocalTime lt=LocalTime.now();
//		System.out.println(lt);
//		System.out.println(lt.getHour());
//		
//		System.out.println(LocalTime.now());
		
		//Uso de Generics<>import java.util.ArrayDeque;
		List<Auto>lista2=new ArrayList();
		lista2.add(new Auto("VW","Gol","Negro"));
		lista1.add(new Auto("Citroen","Ami","Gris"));
		
		Auto a1=(Auto)lista1.get(0);
		Auto a2=lista2.get(0);
		
		//Copiar autos de lista1 a lista2
		lista1.forEach(o->{
			if(o instanceof Auto) {
				lista2.add((Auto)o);
			}
		});
		
		System.out.println("*************************************************************************");
		lista2.forEach(System.out::println);
		
		//Interface Set
		Set<String>semana;
		
		//Implementación HashSet: Es la más veloz de todas, no garantiza el orden de elementos
		//semana=new HashSet();
		
		//Implementación LinkedHashSet: Almacena elementos en una lista enlazada por orden de ingreso
		//semana=new LinkedHashSet();
		
		//Implementación TreeSet: Almacena elementos en un arbol, por orden natural
		semana=new TreeSet();
		
		//app
		semana.add("Lunes");
		semana.add("Martes");
		semana.add("Miércoles");
		semana.add("Jueves");
		semana.add("Viernes");
		semana.add("Sábado");
		semana.add("Domingo");
		semana.add("Lunes");
		semana.add("Lunes");
		semana.add("Viernes");
		semana.forEach(System.out::println);
		
		Set<Auto>setAutos;
		//setAutos=new HashSet();
		//setAutos=new LinkedHashSet();
		setAutos=new TreeSet();
		
		setAutos.addAll(lista2);
		System.out.println("*************************************************************************");
		setAutos.add(new Auto("Citroen","Ami","Gris"));
		setAutos.forEach(a->System.out.println(a+"\t"+a.hashCode()));
		
		String n1="Beatriz";
		String n2="Ana";
		String n3="Ana";
		String n4="Victor";
		
		System.out.println(n1.compareTo(n2));	//1
		System.out.println(n2.compareTo(n1));	//-1
		System.out.println(n2.compareTo(n2));	//0
		
		//Estructura Pila LIFO Last In First Out
		//Clase Stack
		Stack<Auto>pilaAutos=new Stack();
		// .push() Apila un elemento
		pilaAutos.push(new Auto("Renault","Megane","Gris")); //Primero que entra y ultimo que sale
		pilaAutos.addAll(lista2);
		pilaAutos.add(3, new Auto("Fiat","Uno","Rojo"));
		System.out.println("*************************************************************************");
		pilaAutos.forEach(System.out::println);
		
		System.out.println("Longitud pila autos: "+pilaAutos.size());
		while(!pilaAutos.isEmpty()) {
			System.out.println(pilaAutos.pop());
			// .pop() Desapila un auto
		}
		System.out.println("Longitud pila autos: "+pilaAutos.size());
		
		
		//Estructura Cola FIFO First In First Out
		//Clase ArrayDeque
		ArrayDeque<Auto>colaAutos=new ArrayDeque();
		//método offer() para encolar un elemento
		colaAutos.offer(new Auto("Citroen","Berlindo","Bordo"));
		colaAutos.addAll(lista2);
		colaAutos.addFirst(new Auto("Fiat","500","Blanco"));
		System.out.println("*************************************************************************");
		colaAutos.forEach(System.out::println);
		System.out.println("Longitud colaAutos: "+colaAutos.size());
		while(!colaAutos.isEmpty()) {
			System.out.println(colaAutos.poll());
		}
		System.out.println("Longitud colaAutos: "+colaAutos.size());
		
	}

}
