package colecciones;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class Mapas {
	public static void main(String[] args) {
		//Interface Map
		Map<String, String>mapaSemana;
		
		//Implementación HashMap: Es la más veloz, pero desordenada.
		//mapaSemana=new HashMap<String, String>();
		
		//Implementación LinkedHashMap: Almacena elementos en una lista enlazada, por orden de ingreso
		mapaSemana=new LinkedHashMap();
		
		//Implementación TreeMap: Almacena elementos en un arbol, por orden natural
		//mapaSemana=new TreeMap();
		
		//app
//		mapaSemana.put("lu", "oooooo");
//		mapaSemana.put("ma", "Martes");
//		mapaSemana.put("mi", "Miércoles");
//		mapaSemana.put("ju", "Jueves");
//		mapaSemana.put("vi", "Viernes");
//		mapaSemana.put("sa", "Sábado");
//		mapaSemana.put("do", "Domingo");
//		mapaSemana.put("xx", "Lunes");
//		mapaSemana.put("lu", "Lunes");
		
		
		mapaSemana.put("lu", "Monday");
		mapaSemana.put("ma", "Tuesday");
		mapaSemana.put("mi", "Wednesday");
		mapaSemana.put("ju", "Thurday");
		mapaSemana.put("vi", "Fryday");
		mapaSemana.put("sa", "Saturday");
		mapaSemana.put("do", "Sunday");
		
		System.out.println(mapaSemana.get("ju"));
		mapaSemana.forEach((k,v)->System.out.println(k+": "+v));
				
		Map<Empleado,Auto>mapa=new LinkedHashMap();
		Empleado e1=new Empleado("Raquel");
		Empleado e2=new Empleado("Jose");
		Empleado e3=new Empleado("Pedro");
		Empleado e4=new Empleado("Ana");
		
		Auto a1=new Auto("Ford","Fiesta","Rojo");
		Auto a2=new Auto("Fiat","Uno","Gris");
		Auto a3=new Auto("VW","Gol","Blanco");
		Auto a4=new Auto("Renault","Logan","Negro");
		
		mapa.put(e1,a4);
		mapa.put(e2,a3);
		mapa.put(e1,a1);
		mapa.put(e3,a2);
		mapa.put(e4,a3);
		
		System.out.println(mapa.get(e2));
		mapa.forEach((e,a)->System.out.println(e+"\t"+a));
		
		//Diccionario de entorno - Varia segun el SO
		System.getenv().forEach((k,v)->System.out.println(k+"\t"+v));
		System.out.println(System.getenv().get("LOGNAME"));
		
		//Diccionario de propiedades - No cambia en los distintos SO
		System.getProperties().forEach((k,v)->System.out.println(k+"\t"+v));
		System.out.println(System.getProperty("os.name"));
		System.out.println(System.getProperty("os.version"));
		System.out.println(System.getProperty("os.arch"));
		
		
		
		
	}
}
