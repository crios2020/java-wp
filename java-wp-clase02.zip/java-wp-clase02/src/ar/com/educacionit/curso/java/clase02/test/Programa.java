package ar.com.educacionit.curso.java.clase02.test;

import ar.com.educacionit.curso.java.clase02.test2.Persona;

public class Programa {
	public static void main(String[] args) {
		System.out.println("Hola Mundo!");
		Persona p=new Persona("Ana");
		//p.nombre="Analia";
	}
}
