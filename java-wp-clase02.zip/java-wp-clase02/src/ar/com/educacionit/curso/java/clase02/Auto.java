package ar.com.educacionit.curso.java.clase02;

//Declaración de clases
public class Auto {

	//Miembros de clases: Atributos, Métodos o clases internar
	
	//Atributos
	String marca;
	String modelo;
	String color;
	//String tipo;		//Auto 120, Micro 90, Camión 80
	//Motor motor;
	int velocidad;
	
	//Declaración de clase interna
	//No recomendamos su uso
	//Representa una clase de motor que solo funciona en este Auto
	//class Motor{}
	
	//Métodos constructores
	
	/**
	 * Este método fue deprecado por Carlos Ríos el 18/06/2022, por considerarse inseguro
	 * y no funcional. Usar en su reemplazo Auto(String marca, String modelo, String color)
	 */
	@Deprecated
	Auto(){
		//Constructor Vacio
		//Annotation aparecieron en JDK 5 o sup.
		//Annotation @Deprected significa que se considera inseguro el método y que puede
		//ser borrado en una siguiente versión del producto.
	} 
	
	Auto(String marca, String modelo, String color){
		this.marca=marca;
		this.modelo=modelo;
		this.color=color;
	}
	
	//Métodos
	void acelerar() {									//acelerar()
		//velocidad+=10;
		//if(velocidad>100) velocidad=100;
		acelerar(10);		//llamado a método dentro de la misma clase
	}
	
	//Método sobrecargado.
	//Método con ingreso de parámetros
	/**
	 * @param kilometros cantidad de kilometros por hora a incrementar velocidad.
	 */
	void acelerar(int kilometros) {						//acelerarInt
		velocidad+=kilometros;
		if(velocidad>100) velocidad=100;
	}
	
	void acelerar(int x, String t) {}					//acelerarIntString
	
	void frenar() {
		velocidad-=10;
	}
	
	void imprimirVelocidad() {
		System.out.println(velocidad);
	}
	
	//Método con valor de retorno
	int obtenerVelocidad() {
		return velocidad;
	}
	
	//Sobreescribimos el método toString()
	@Override
	public String toString() {
		return marca+" "+modelo+" "+color+" "+velocidad;
	}
	
}	//end class
