package ar.com.educacionit.curso.java.clase02.test2;

public class Programa {
	public static void main(String[] args) {
		Persona p=new Persona("Ana");
		p.nombre="Analia";
	}
}
