package ar.com.educacionit.curso.java.clase02;

public class Humano {
	String nombre;
	int edad;
	int altura;
	int peso;
	Cabeza cabeza;
	
	
	class Cabeza{
		
	}
}
