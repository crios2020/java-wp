package ar.com.educacionit.curso.java.clase02;
import javax.swing.JOptionPane;

public class Clase02 {

	public static void main(String[] args) {
		// Clase 02 Paradigma de objetos
		
		/*
		 Que es una clase? Una clase se detecta como sustantivo. Representa ideas genericas.
		 
		 Una clase en java? Todas clases son objetos de la clase java.lang.Class
		 
		 Una clase tiene miembros, esos miembros pueden ser atributos, métodos u otros clases.
		 
		 Que es un Objeto? Un objeto es una instancia en particular de una clase y tiene un 
		 estado propio.
		 
		 Que es un atributo? Un atributo describe a la clase y tiene un tipo de datos asociado.
		 La clase define los atributos, y los objetos completan el estado (valor de los atributos)
		 Son adjetivos de la clase. Son variables contenidas dentro de la clase.
		 Los atributos tienen una inicialización automatica.
		 Los atributos númericos se inicializan en 0.
		 Los atributos String se inicializan en null.
		 
		 Un atributo en java? Es un objeto de la clase java.lang.reflect.Field
		 
		 
		 Que es un método? Son acciones que realiza la clase, se detecta como verbo.
		 
		 Un método en java? Es un objeto de la clase java.lang.reflect.Method
		 
		 Que son los parámetros de entrada: son valores enviados al métodos, y el mètodo toma
		 esos parámetros como varialbes locales y realiza acciones.
		 
		 Que el valor de retorno: Que un valor retornado despues de realizar cierta operación.
		 
		 Sobrecarga de métodos: es la presencia de métodos con el mismo nombre dentro de una clase,
		 pero varia la firma de parámetros de entrada.
		 
		 
		 Que son los métodos constructores? son métodos sin devolución de valor que se ejecutan
		 automáticamente al crear un objeto. Sirve para inicializar un objeto. Puede sobrecargarse
		 y puede recibir parámetros de entrada. Tiene el mismo nombre que la clase e inicia con
		 mayúsculas.
		 Si no hay constructor declarado, Java agrega un constructor vacio al compilar.
		 
		 Los constructores en Java, son objetos de la clase java.lang.reflect.Constructor
		*/
		
		System.out.println("-- auto1 --");
		Auto auto1=new Auto();			//llama a un método constructor vacio.
		auto1.marca="Ford";
		auto1.modelo="Ka";
		auto1.color="Negro";
		auto1.acelerar();			// 10
		auto1.acelerar();			// 20
		auto1.acelerar();			// 30
		auto1.frenar();				// 20
		auto1.acelerar(25);			// 45
		
		System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.velocidad);
		
		
		//La variablen deben ser inicializadas
		int x;
		//System.out.println(x); //Error variable no inicializada
		
		System.out.println("-- auto2 --");
		Auto auto2=new Auto();
		auto2.marca="Fiat";
		auto2.modelo="Strada";
		auto2.color="Rojo";
		
		for(int a=0; a<=60; a++) {
			auto2.acelerar();
		}
		
		System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color+" "+auto2.velocidad);
		auto2.imprimirVelocidad();
		System.out.println(auto2.obtenerVelocidad());
		
		//JOptionPane.showMessageDialog(null, "Velocidad: "+auto2.obtenerVelocidad());
	
		System.out.println("-- auto3 --");
		Auto auto3=new Auto("Citroen","C4","Azul");
		auto3.acelerar();
		
		//Método toString()
		System.out.println(auto3.toString());
		System.out.println(auto3);
		
		Calculadora cal=new Calculadora();
		System.out.println(cal.sumar(28,65));
		System.out.println(cal.restar(30, 14));
		System.out.println(cal.multiplicar(2, 45));
		System.out.println(cal.dividir(38, 2));
		//System.out.println(cal.dividir(38, 0));
		
		//Clase Empleado
		Empleado e1=new Empleado(1,"Victor","Costabel",150000);
		//e1.sueldoBasico=3000000;
		e1.setSueldoBasico(3000000);
		System.out.println(e1);
		
		/*
		 	Operadores de visibilidad de miembros de clases (atributo o mètodo)
		 	
		 	Operador			Alcance
		 	default(omitido)	Se puede acceder al miembro de clase desde la misma clase
		 						o desde clases del mismo paquete.
		 	
		 	public				Puede acceder al miembro de clase desde la misma clase
		 						y desde clases del cualquier paquete.
		 						
		 	private				Solo puede acceder al miembro de clase desde la misma clase.
		 	
		 	protected			Solo puede acceder al miembro de clase desde la misma clase
		 						desde clases hijas, y desde clases del mismo paquete.
		 
		 */
		
	}

}
