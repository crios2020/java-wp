package ar.com.educacionit.curso.java.clase02;

public class Calculadora {
	public double sumar(double nro1, double nro2) {
		//método sumar
		return nro1+nro2;
	}
	
	public double restar(double nro1, double nro2) {
		//método restar
		return nro1-nro2;
	}
	
	public double multiplicar(double nro1, double nro2) {
		//método multiplicar
		return nro1*nro2;
	}
	
	public double dividir(double nro1, double nro2) {
		//método dividir, en caso de que nro2 sea distinto de 0
		if(nro2==0) throw new ArithmeticException("Error División por 0");
		return nro1/nro2;
	}
}
