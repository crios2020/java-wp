package ar.com.educacionit.curso.java.clase02;

public class Pedido {
	
	int cant;
	String combo;
	boolean agrandado;
	String gaseosa;
	
	void pedir(int cant, String combo, boolean agrandado, String gaseosa, String tarjeta) {
		
	}
	
	void pedir(int cant, String combo, boolean agrandado, String gaseosa) {
		
	}
	
	void pedir(int cant, String combo, boolean agrandado) {
		
		gaseosa="CocaCola";
	}
}
