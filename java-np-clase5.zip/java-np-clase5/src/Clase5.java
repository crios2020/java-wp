import java.util.Arrays;

public class Clase5 {

	public static void main(String[] args) {
		// Clase 5  Arrays - Vectores
		
		int[] numeros=new int[4];
		String[] nombres=new String[4];
		
		numeros[0]=1;
		nombres[0]="Juan";
		numeros[1]=2;
		nombres[1]="Maria";
		numeros[2]=3;
		nombres[2]="Jose";
		numeros[3]=4;
		nombres[3]="Ana";
		
		//La primer posición de un array tiene indice 0, 
		//la ultima posición tiene como indice la longitud-1  
		//numeros[4]=5;			//error fuera del vector
		//nombres[4]="Mirta";
		
		/*
		 * 		numeros			nombres				indice
		 * 			1			Juan				0
		 * 			2			Maria				1
		 * 			3			Jose				2	
		 * 			4			Ana					3
		 */
		
		System.out.println(numeros[2]+" "+nombres[2]);
		System.out.println("***********************************************************");
		
		//Recorrido usando for
		for(int a=0; a<4; a++) {
			System.out.println(numeros[a]+" "+nombres[a]);
		}

		//Método length
		System.out.println("longitud numeros: "+numeros.length);
		
		//Recorrido con método length
		for(int a=0; a<numeros.length; a++) {
			System.out.println(numeros[a]+" "+nombres[a]);
		}
		
		//Recorrido con while
		int b=0;
		while(b<numeros.length) {
			System.out.println(numeros[b]+" "+nombres[b]);
			b++;
		}
		
		//Recorrido inverso
		for(int a=numeros.length-1; a>=0; a--) {
			System.out.println(numeros[a]+" "+nombres[a]);
		}
		
		//vector String[] args
		
		//Definición abreviada
		int[] vector={10, 23, 26, 29, 39, 38, 10, 6, 65, 24};
		System.out.println("Longitud vector: "+vector.length);
		for(int a=0; a<vector.length; a++){
			System.out.print(vector[a]+", ");
		}
		
		//Totalizar un vector
		//Calcular promedio
		int total=0;
		for(int a=0; a<vector.length; a++){
			total+=vector[a];
		}
		System.out.println();
		System.out.println("Total: "+total);
		System.out.println("Promedio: "+(total/vector.length));
		
		//Buscar el valor máximo y valor mínimo
		int max=vector[0];
		int min=vector[0];
		for(int a=0; a<vector.length; a++) {
			if(max<vector[a]) {
				max=vector[a];
			}
			if(min>vector[a]) {
				min=vector[a];
			}
		}
		System.out.println("Valor máximo: "+max);
		System.out.println("Valor mínimo: "+min);
		
		vector[5]=17;
		vector[6]=23;
		vector[7]=45;
		vector[8]=10;
		vector[9]=10;
		
		//Contar cantidad de números pares e impares
		//Contar cuantas veces se repite el nro 10
		int contPar=0, contImpar=0, cont10=0;
		for(int a=0; a<vector.length; a++) {
			if(vector[a]%2==0) contPar++;
			else contImpar++;
			if(vector[a]==10) cont10++;
		}
		System.out.println("cantidad Pares: "+contPar);
		System.out.println("cantidad Impares: "+contImpar);
		System.out.println("cantidad 10: "+cont10);
		
		for(int a=0; a<vector.length; a++){
			System.out.print(vector[a]+", ");
		}
		System.out.println();
		
		//ordenar vectores
		Arrays.sort(vector);
		
		for(int a=0; a<vector.length; a++){
			System.out.print(vector[a]+", ");
		}
		System.out.println();
		
		//Recorrido inverso
		for(int a=vector.length-1; a>=0; a--) {
			System.out.print(vector[a]+", ");
		}
		System.out.println();
		
		//Copiar vectores
		int[] pares= {2, 4, 6, 8, 10};
		int[] impares=new int[pares.length];
		int[] pares2=new int[pares.length];
		
		/*
		 * 		pares			impares		pares2
		 * 			2			_0_			_0_
		 * 			4			_0_			_0_
		 * 			6			_0_			_0_
		 * 			8			_0_			_0_
		 * 		   10			_0_			_0_
		 */
		
		for(int i=0; i<pares.length; i++) {
			impares[i]=pares[i]-1;
		}
		
		for(int i=0; i<pares.length; i++) {
			System.out.println(impares[i]+" "+pares[i]);
		}
		
		//Copiar vectores usando Arraycopy
		System.arraycopy(pares, 0, pares2, 0, pares.length);
		
		for(int i=0; i<pares.length; i++) {
			System.out.println(pares[i]+" "+pares2[i]);
		}
		
		
	}

}
