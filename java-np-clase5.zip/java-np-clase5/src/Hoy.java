import java.time.LocalDateTime;

public class Hoy {
	public static void main(String[] args) {
		LocalDateTime ldt=LocalDateTime.now();
		//System.out.println(ldt);
		int año=ldt.getYear();
		int mes=ldt.getMonth().getValue();
		int dia=ldt.getDayOfMonth();
		int diaSem=ldt.getDayOfWeek().getValue();
		
		String nombreDia="";
		String nombreMes="";
		
		switch(diaSem) {
			case 1: nombreDia="Lunes"; 		break;
			case 2: nombreDia="Martes"; 	break;
			case 3: nombreDia="Miércoles"; 	break;
			case 4: nombreDia="Jueves"; 	break;
			case 5: nombreDia="Viernes"; 	break;
			case 6: nombreDia="Sábado"; 	break;
			case 7: nombreDia="Domingo"; 	break;
		}
		
		switch(mes) {
			case 1: 	nombreMes="Enero"; 		break;
			case 2: 	nombreMes="Febrero"; 	break;
			case 3: 	nombreMes="Marzo"; 		break;
			case 4: 	nombreMes="Abril"; 		break;
			case 5: 	nombreMes="Mayo"; 		break;
			case 6: 	nombreMes="Junio"; 		break;
			case 7: 	nombreMes="Julio"; 		break;
			case 8: 	nombreMes="Agosto"; 	break;
			case 9: 	nombreMes="Septiembre"; break;
			case 10: 	nombreMes="Octubre"; 	break;
			case 11: 	nombreMes="Noviembre"; 	break;
			case 12: 	nombreMes="Diciembre"; 	break;
		}
		
		System.out.println("Hoy es "+nombreDia+" "+dia+" de "+nombreMes+" de "+año);
		
		
		
	}
}
