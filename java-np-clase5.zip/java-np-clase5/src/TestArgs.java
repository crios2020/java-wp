
public class TestArgs {
	public static void main(String[] args) {
		//String[] args: contiene argumentos que se ingresan por consola
		System.out.println("Longitud args: "+args.length);
		for(int i=0; i<args.length; i++) {
			System.out.println(args[i]);
		}
	}
}
